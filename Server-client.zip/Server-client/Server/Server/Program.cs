﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Server
{
    class Program
    {


        static void Main(string[] args)
        {
            Socket listenerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);
            listenerSocket.Bind(ipEnd);

            int clientNo = 1;

            while (true)
            {

                listenerSocket.Listen(0);
                Socket clientSocket = listenerSocket.Accept();

                Thread clientThread;
                clientThread = new Thread(() => Clientconnection(clientSocket, clientNo));
                clientThread.Start();
                clientNo++;
            }

        }

        private static void Clientconnection(Socket clientSocket, int clno)
        {
            byte[] Buffer = new byte[clientSocket.SendBufferSize];
            int readByte;

            do
            {

                readByte = clientSocket.Receive(Buffer);
                byte[] rData = new byte[readByte];
                Array.Copy(Buffer, rData, readByte);
                Console.WriteLine("Client " + clno.ToString() + ":" + System.Text.Encoding.UTF8.GetString(rData));

                clientSocket.Send(new byte[4] { 65, 70, 68, 69 });

            } while (readByte > 0);



            Console.WriteLine("Disconnected Client");
            Console.ReadKey();
        }
    }
}
